//
//  ShufflingFigureView.h
//  PandaFM
//
//  Created by 洛洛大人 on 16/9/22.
//  Copyright © 2016年 洛洛大人. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ShufflingFigureView : UIView

@property (nonnull, strong) NSMutableArray *arrayOfShuff;

@end
