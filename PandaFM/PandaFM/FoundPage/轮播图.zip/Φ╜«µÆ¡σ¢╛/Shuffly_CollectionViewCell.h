//
//  Shuffly_CollectionViewCell.h
//  PandaFM
//
//  Created by 洛洛大人 on 16/9/22.
//  Copyright © 2016年 洛洛大人. All rights reserved.
//

#import <UIKit/UIKit.h>
@class Shuffly_Model;
@interface Shuffly_CollectionViewCell : UICollectionViewCell

@property (nonatomic, retain) Shuffly_Model *modelOfShuffly;

@end
