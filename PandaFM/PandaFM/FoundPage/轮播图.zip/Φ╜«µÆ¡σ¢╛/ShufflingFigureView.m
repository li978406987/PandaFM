//
//  ShufflingFigureView.m
//  PandaFM
//
//  Created by 洛洛大人 on 16/9/22.
//  Copyright © 2016年 洛洛大人. All rights reserved.
//

#import "ShufflingFigureView.h"
#import "Shuffly_CollectionViewCell.h"

@interface ShufflingFigureView ()
<
UICollectionViewDelegate,
UICollectionViewDataSource
>
@property (nonatomic, strong) UICollectionView *collectionViewShuffly;


@end

@implementation ShufflingFigureView

- (void) creatCollectionViewOfShuffly {
    UICollectionViewFlowLayout *FlowLayout = [[UICollectionViewFlowLayout alloc] init];
    
    FlowLayout.itemSize = CGSizeMake(self.frame.size.width, 220);
    
    FlowLayout.minimumInteritemSpacing = 0;
    FlowLayout.minimumLineSpacing = 0;
    
    FlowLayout.scrollDirection = UICollectionViewScrollDirectionHorizontal;
    
    self.collectionViewShuffly = [[UICollectionView alloc] initWithFrame:CGRectMake(0, 0, self.frame.size.width, 220) collectionViewLayout:FlowLayout];
    
    _collectionViewShuffly.backgroundColor = [UIColor grayColor];
    
    _collectionViewShuffly.pagingEnabled = YES;
    _collectionViewShuffly.delegate = self;
    _collectionViewShuffly.dataSource = self;
    
    
    [_collectionViewShuffly registerClass:[Shuffly_CollectionViewCell class] forCellWithReuseIdentifier:@"cellOfShuffly"];
    
    
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {

    return _arrayOfShuff.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    Shuffly_CollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"cellOfShuffly" forIndexPath:indexPath];
    Shuffly_Model *modelOfShuffly = [self.arrayOfShuff objectAtIndex:indexPath.row];
    cell.modelOfShuffly = modelOfShuffly;
    
    return cell;
}

- (void)setArrayOfShuff:(NSMutableArray *)arrayOfShuff {
    if (_arrayOfShuff != arrayOfShuff) {
        _arrayOfShuff = arrayOfShuff;
    }
    [_collectionViewShuffly reloadData];
}




@end
